
def command(*args, **kwargs):
    import cg3dcasc
    cg3dcasc.export_scene(True)
